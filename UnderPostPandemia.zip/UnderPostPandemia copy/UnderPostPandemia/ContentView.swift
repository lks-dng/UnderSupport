//
//  ContentView.swift
//  UnderSupport AR
//
//  Created by Lucas Rdc on 10/03/2023.
//

import SwiftUI

struct ContentView: View {
    
    @State var goToCart = false
    
    var columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var items: [[Any]] = bands
    
    var body: some View {
        NavigationStack {
            TabView {
                VStack {
                    VStack (spacing: 5){
                        VStack {
                        Text("Under")
                            .frame(width: 320, alignment: .leading)
                            .foregroundColor(.gray)
                        Text("Post Pandemia")
                            .font(.system(size: 38, weight: .semibold, design: .rounded))
                            .frame(width: 320, alignment: .leading)
                        Spacer().frame(height: 20)
                        Text("Bandas:")
                            .frame(width: 320, alignment: .leading)
                            .foregroundColor(.gray)
                        
                    }.padding(10)
                        ScrollView() {
                            LazyVGrid(columns: columns, spacing: 30) {
                                ForEach(0..<items.count, id:\.self) { item in
                                    ShopItem(imageName: items[item][0] as! String, title: items[item][1] as! String, price: items[item][2] as! Double, color: items[item][3] as! Color, selfIndex: item)
                                }
                            }
                        }.padding(15)
                    }
                    .navigationDestination(isPresented: $goToCart) {
                        Cart()
                    }
                    .toolbar(){
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button(){
                                goToCart = true
                            }label: {
                                Image(systemName: "cart")
                            }
                        }
                    }
                }
                .tabItem {
                    Image(systemName: "guitars")
                    Text("Bandas")
                }
                
                VStack {
                    
                }
                .tabItem {
                    Image(systemName: "calendar")
                    Text("Eventos")
                }
                VStack {
                    
                }
                .tabItem {
                    Image(systemName: "map")
                    Text("Lugares")
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
