//
//  Data.swift
//  UnderSupport AR
//
//  Created by Lucas Rdc on 16/03/2023.
//

import SwiftUI

var bands: [[Any]] = [
    ["KillFlora", "Kill Flora", 800.00, Color.pink],
    ["WinonaRiders", "Winona Riders", 900.00, Color.gray],
    ["ElClubAudiovisual", "El Club Audiovisual", 800.00, Color.black],
    ["LasTussi", "Las Tussi", 1000.00, Color.orange],
    ["Socorro", "Socorro", 600.00, Color.green],
]

var places : [[Any]] = [
    ["Laberinto", "El Laberinto", "Ver Eventos", Color.pink],
    ["Emergente", "El Emergente", "Ver Eventos", Color.gray],
    ["Moscu", "Moscú", "Ver Eventos", Color.black],
    ["OtraHistoria", "Otra Historia", "Ver Eventos", Color.orange],
    ["Niceto", "Niceto Club", "Ver Eventos", Color.green],
]

var cartItems: [[Any]] = [
]
