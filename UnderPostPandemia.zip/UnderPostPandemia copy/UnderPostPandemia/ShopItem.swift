//
//  ShopItem.swift
//  UnderSupport AR
//
//  Created by Lucas Rdc on 10/03/2023.
//

import SwiftUI

struct ShopItem: View {
    
    var imageName : String
    var title : String
    var price : Double
    var color : Color
    var selfIndex : Int
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .foregroundColor(color)
                .opacity(0.10)
                .frame(width: 170, height: 230)
            VStack {
                Image(imageName)
                    .resizable()
                    .frame(width: 110, height: 110)
                Text(title)
                Button() {
                    cartItems.append(bands[selfIndex])
                } label : {
                    Text("$\(String(format:"%.2f",price))")
                        .foregroundColor(.white)
                        .frame(width: 100, height: 40)
                        .background(Color.blue)
                    
                }
            }
        }
    }
}

struct ShopItem_Previews: PreviewProvider {
    static var previews: some View {
        ShopItem(imageName : "KillFlora",
                 title : "Kill Flora",
                 price : 800,
                 color : Color.gray,
                 selfIndex : 001)
    }
}
