//
//  UnderPostPandemiaApp.swift
//  UnderPostPandemia
//
//  Created by Lucas Rdc on 19/03/2023.
//

import SwiftUI

@main
struct UnderPostPandemiaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
