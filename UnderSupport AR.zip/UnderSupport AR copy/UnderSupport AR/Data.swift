//
//  Data.swift
//  UnderSupport AR
//
//  Created by Lucas Rdc on 16/03/2023.
//

import SwiftUI

var shopItems: [[Any]] = [
    ["KillFlora", "Kill Flora", 800.00, Color.pink],
    ["WinonaRiders", "Winona Riders", 900.00, Color.gray],
    ["ElClubAudiovisual", "El Club Audiovisual", 800.00, Color.black],
    ["LasTussi", "Las Tussi", 1000.00, Color.orange],
    ["Socorro", "Socorro", 600.00, Color.green],
]

var cartItems: [[Any]] = [
]
