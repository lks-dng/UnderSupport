//
//  UnderSupport_ARApp.swift
//  UnderSupport AR
//
//  Created by Lucas Rdc on 10/03/2023.
//

import SwiftUI

@main
struct UnderSupport_ARApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
