//
//  ContentView.swift
//  UnderSupport AR
//
//  Created by Lucas Rdc on 10/03/2023.
//

import SwiftUI

struct ContentView: View {
    
    @State var changeScreen = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 50){
                Image("KillFlora")
                    .resizable()
                    .scaledToFit()
                    .frame(width:300, height: 300)
                Text("Under Support")
                    .font(.system(size: 25, weight: .bold, design: .monospaced))
                    .multilineTextAlignment(.center)
                Text("Aqui podras comprar la muscia de tus artistas favoritos y apoyarlos economicamente")
                    .multilineTextAlignment(.center)
                    .foregroundColor(.gray)
                Button() {
                    changeScreen =  true
                }label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 50)
                        Text("Ver bandas")
                            .font(.system(size: 14))
                            .foregroundColor(.white)
                            .bold()
                    }
                }.frame(width: 130, height: 45)
                    .foregroundColor(.purple)
 
            }
            .navigationDestination(isPresented:  $changeScreen) {
                Shop()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
